#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// functie scriere date binare in fisier
void writebin(const char *filename, unsigned char *data, size_t size) 
{
    FILE *file = fopen(filename, "ab");
    if (file == NULL) 
    {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    fwrite(data, 1, size, file);
    fclose(file);
}

int main(int argc, char *argv[]) 
{
    if (argc != 2) 
    {
        fprintf(stderr, "Usage: %s <nume_fisier>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    FILE *file = fopen(argv[1], "r");
    if (file == NULL) 
    {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    char line[256];
    while (fgets(line, sizeof(line), file) != NULL)  //prelucrare date
    {
        // ignorare label
        if (line[0] == '.') 
        {
            continue;
        }

        // ignorare comm
        if (line[0] == '#') 
        {
            continue;
        }

        line[strcspn(line, "\r\n")] = '\0'; // sterge linie noua

        // transform linia in token
        char *tok = strtok(line, ", ");
        while (tok != NULL) 
        {
            if (strcmp(tok, "") != 0) 
            {
                printf("%s\n", tok);

                // verificam daca functia e add
                if (toupper(tok[0]) == 'A' && toupper(tok[1]) == 'D' && tok[2] == 'D') 
                {
                    // numar registru
                    int r = toupper(tok[3]) - '0';

                    // numar registru valid
                    if (r >= 0 && r <= 7) 
                    {
                        // operand
                        char *a1 = strtok(NULL, ", ");
                        if (a1[0] == 'R') 
                        {
                            // operand registru
                            int r2 = strtol(a1 + 1, NULL, 0);
                            // creaza si scire functie
                            unsigned char b[] = {0x42, r, 0, r2};
                            writebin("rom.bin", b, sizeof(b));
                        } 
                        else 
                        {
                            // opernad valoare
                            int v = strtol(a1, NULL, 0);
                            // creeaza si scrie functie binara
                            unsigned char b[] = {0x40, r, v >> 8, v & 0xFF};
                            writebin("rom.bin", b, sizeof(b));
                        }
                    } 
                    else 
                    {
                        printf("Invalid register name\n");
                        printf("%c\n", tok[3]);
                        fclose(file);
                        exit(EXIT_FAILURE);
                    }
                }
            }

            else if (toupper(tok[0]) == 'L' && toupper(tok[1]) == 'D' && toupper(tok[1]) == 'R') 
        {
            int r = toupper(tok[2]) - '0';
            if (r >= 0 && r <= 7) 
            {
                char *a1 = strtok(NULL, " ");
                if (a1[0] == '$') 
                {
                    // adresa
                    int addr = strtol(&a1[1], NULL, 0);
                    unsigned char b[] = {0x02, r, addr >> 8, addr & 0xFF};
                    writebin("rom.bin", b, sizeof(b));
                } 
                else if (a1[0] == 'R') 
                {
                    // registru
                    int r2 = strtol(&a1[1], NULL, 0);
                    unsigned char b[] = {0x01, r, 0, r2};
                    writebin("rom.bin", b, sizeof(b));
                } 
                else 
                {
                    // valoare
                    int v = strtol(a1, NULL, 0);
                    unsigned char b[] = {0x00, r, v >> 8, v & 0xFF};
                    writebin("rom.bin", b, sizeof(b));
                }
            } 
            else 
            {
                printf("Invalid register name\n");
                printf("%c\n", tok[2]);
                fclose(file);
                exit(EXIT_FAILURE);
            }
        } 
        else if (toupper(tok[0]) == 'S' && toupper(tok[1]) == 'T' && toupper(tok[1]) == 'R') 
        {
            int r = toupper(tok[2]) - '0';
            if (r >= 0 && r <= 7) 
            {
                char *a1 = strtok(NULL, " ");
                if (a1[0] == '$') 
                {
                    // adresa
                    int addr = strtol(&a1[1], NULL, 0);
                    unsigned char b[] = {0x10, r, addr >> 8, addr & 0xFF};
                    writebin("rom.bin", b, sizeof(b));
                } 
                else if (a1[0] == 'R') 
                {
                    // adresa in registru
                    int r2 = strtol(&a1[1], NULL, 0);
                    unsigned char b[] = {0x13, r, 0, r2};
                    writebin("rom.bin", b, sizeof(b));
                } 
                else 
                {
                    printf("Invalid mode\n");
                    printf("%s\n", line);
                    fclose(file);
                    exit(EXIT_FAILURE);
                }
            } 
            else 
            {
                printf("Invalid register name\n");
                printf("%c\n", tok[2]);
                fclose(file);
                exit(EXIT_FAILURE);
            }
        }

        else if (toupper(tok[0]) == 'C' && toupper(tok[1]) == 'M' && tok[2] == 'P')
        {
            int r = toupper(tok[1]) - '0';
            if (r >= 0 && r <= 7) 
            {
                char *a1 = strtok(NULL, " ");
                if (a1[0] == 'R') 
                {
                    //registru
                    int r2 = strtol(&a1[1], NULL, 0);
                    unsigned char b[] = {0x20, r, 0, r2};
                    writebin("rom.bin", b, sizeof(b));
                } 
                else 
                {
                    // valoare
                    int v = strtol(a1, NULL, 0);
                    unsigned char b[] = {0x21, r, v >> 8, v & 0xFF};
                    writebin("rom.bin", b, sizeof(b));
                }
            } 
            else 
            {
                printf("Invalid register name\n");
                printf("%c\n", tok[1]);
                fclose(file);
                exit(EXIT_FAILURE);
            }
        }

            tok = strtok(NULL, ", ");
        }
    }

    fclose(file);
    return 0;
}
